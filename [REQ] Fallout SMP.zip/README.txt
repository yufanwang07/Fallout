[REQ] Fallout SMP

Adds the Pale Blade model and texture.

Target item data:
netherite_sword[minecraft:custom_data={fallout_smp:{legendary_weapon:"pale_blade"}}]

Built for Minecraft Java Edition 1.21.11 resource pack version 75.0.
